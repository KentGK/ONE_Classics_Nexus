using System;
using System.Threading;
using System.Threading.Tasks;
using ONE_Classics_Nexus.Application.Valuation.Interfaces;
using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Infrastructure.Valuation.Repositories;

/// <summary>
/// Starter persistence repository for valuation runs.
/// </summary>
/// <remarks>
/// Replace this stub with the concrete implementation that writes to
/// valuation_runs and valuation_trace_lines using your existing database stack.
/// </remarks>
public sealed class ValuationRunRepository : IValuationRunRepository
{
    /// <inheritdoc />
    public Task SaveAsync(Guid appraisalId, ValuationResult result, CancellationToken ct)
    {
        // TODO:
        // 1. Insert valuation_runs record.
        // 2. Insert valuation_trace_lines records.
        // 3. Wrap the operation in a transaction.
        // 4. Honor the provided cancellation token in database calls.
        _ = appraisalId;
        _ = result;
        _ = ct;

        return Task.CompletedTask;
    }
}