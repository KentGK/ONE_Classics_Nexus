using Microsoft.Extensions.DependencyInjection;
using ONE_Classics_Nexus.Application.Valuation.Interfaces;
using ONE_Classics_Nexus.Application.Valuation.Services;
using ONE_Classics_Nexus.Domain.Valuation.Abstractions;
using ONE_Classics_Nexus.Domain.Valuation.Engines;
using ONE_Classics_Nexus.Infrastructure.Valuation.Repositories;

namespace ONE_Classics_Nexus.Infrastructure.DependencyInjection;

/// <summary>
/// Registers valuation-related services into the DI container.
/// </summary>
public static class ValuationServiceRegistration
{
    /// <summary>
    /// Adds the Phase 2 valuation stack to the service collection.
    /// </summary>
    public static IServiceCollection AddValuationServices(this IServiceCollection services)
    {
        services.AddScoped<IConditionEngine, DefaultConditionEngine>();
        services.AddScoped<ISimilarityEngine, DefaultSimilarityEngine>();
        services.AddScoped<IComparableEngine, DefaultComparableEngine>();
        services.AddScoped<IMarketEngine, DefaultMarketEngine>();
        services.AddScoped<IConfidenceEngine, DefaultConfidenceEngine>();
        services.AddScoped<IValuationEngine, DefaultValuationEngine>();

        services.AddScoped<IValuationApplicationService, ValuationApplicationService>();
        services.AddScoped<IValuationRunRepository, ValuationRunRepository>();

        return services;
    }
}