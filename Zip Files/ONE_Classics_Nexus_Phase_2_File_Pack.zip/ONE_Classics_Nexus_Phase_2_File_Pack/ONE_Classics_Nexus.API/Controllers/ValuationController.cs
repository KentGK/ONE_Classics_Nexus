using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ONE_Classics_Nexus.Application.Valuation.DTOs;
using ONE_Classics_Nexus.Application.Valuation.Interfaces;

namespace ONE_Classics_Nexus.API.Controllers;

/// <summary>
/// Exposes valuation execution endpoints for appraisals.
/// </summary>
[ApiController]
[Route("api/appraisals/{appraisalId:guid}/valuation")]
public sealed class ValuationController : ControllerBase
{
    private readonly IValuationApplicationService _valuationApplicationService;

    /// <summary>
    /// Initializes a new instance of the <see cref="ValuationController"/> class.
    /// </summary>
    public ValuationController(IValuationApplicationService valuationApplicationService)
    {
        _valuationApplicationService = valuationApplicationService;
    }

    /// <summary>
    /// Runs the valuation engine for the specified appraisal.
    /// </summary>
    /// <param name="appraisalId">The appraisal identifier.</param>
    /// <param name="ct">The request cancellation token.</param>
    /// <returns>The completed valuation result.</returns>
    [HttpPost("run")]
    [ProducesResponseType(typeof(ValuationResultDto), StatusCodes.Status200OK)]
    public async Task<ActionResult<ValuationResultDto>> Run(Guid appraisalId, CancellationToken ct)
    {
        ValuationResultDto result = await _valuationApplicationService.RunAsync(appraisalId, ct);
        return Ok(result);
    }
}