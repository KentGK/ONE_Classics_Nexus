using System;
using ONE_Classics_Nexus.Domain.Valuation.Engines;
using ONE_Classics_Nexus.Domain.Valuation.Models;
using Xunit;

namespace ONE_Classics_Nexus.Tests.Domain.Valuation;

/// <summary>
/// Unit tests for <see cref="DefaultSimilarityEngine"/>.
/// </summary>
public sealed class DefaultSimilarityEngineTests
{
    /// <summary>
    /// Verifies that a close subject-to-comparable match scores highly.
    /// </summary>
    [Fact]
    public void CalculateSimilarity0To1_Returns_High_Score_For_Close_Match()
    {
        var sut = new DefaultSimilarityEngine();

        var subject = new SubjectVehicle(Guid.NewGuid(), 1970, "Chevrolet", "K10", null, "Pickup", "6.0 LS", "4L80E", "4x4", "K10", 12000m, null);
        var comp = new ComparableSale(Guid.NewGuid(), 1970, "Chevrolet", "K10", null, "Pickup", "6.0 LS", "4L80E", "4x4", "K10", 60000m, DateTime.UtcNow, "BAT", null, 11000m, null, null);

        decimal result = sut.CalculateSimilarity0To1(subject, comp);

        Assert.True(result >= 0.90m);
    }
}