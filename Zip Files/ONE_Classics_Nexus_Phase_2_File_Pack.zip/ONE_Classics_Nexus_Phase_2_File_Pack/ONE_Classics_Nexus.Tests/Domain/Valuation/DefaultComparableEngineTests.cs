using System;
using System.Collections.Generic;
using ONE_Classics_Nexus.Domain.Valuation.Engines;
using ONE_Classics_Nexus.Domain.Valuation.Models;
using Xunit;

namespace ONE_Classics_Nexus.Tests.Domain.Valuation;

/// <summary>
/// Unit tests for <see cref="DefaultComparableEngine"/>.
/// </summary>
public sealed class DefaultComparableEngineTests
{
    /// <summary>
    /// Verifies that an adjusted comparable list is produced.
    /// </summary>
    [Fact]
    public void AdjustComparables_Returns_Adjusted_Comparable_List()
    {
        var similarity = new DefaultSimilarityEngine();
        var sut = new DefaultComparableEngine(similarity);

        var subject = new SubjectVehicle(Guid.NewGuid(), 1970, "Chevrolet", "K10", null, "Pickup", "6.0 LS", "4L80E", "4x4", "K10", 12000m, null);
        var comps = new[]
        {
            new ComparableSale(Guid.NewGuid(), 1970, "Chevrolet", "K10", null, "Pickup", "6.0 LS", "4L80E", "4x4", "K10", 60000m, DateTime.UtcNow.AddMonths(-2), "BAT", null, 10000m, null, null)
        };

        IReadOnlyList<AdjustedComparable> result = sut.AdjustComparables(subject, comps, 80m);

        Assert.Single(result);
    }
}