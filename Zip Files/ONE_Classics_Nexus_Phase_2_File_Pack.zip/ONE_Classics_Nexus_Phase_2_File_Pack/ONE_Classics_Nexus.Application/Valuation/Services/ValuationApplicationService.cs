using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ONE_Classics_Nexus.Application.Valuation.DTOs;
using ONE_Classics_Nexus.Application.Valuation.Interfaces;
using ONE_Classics_Nexus.Domain.Valuation.Abstractions;
using ONE_Classics_Nexus.Domain.Valuation.Models;
using ONE_Classics_Nexus.Domain.Valuation.Versioning;

namespace ONE_Classics_Nexus.Application.Valuation.Services;

/// <summary>
/// Default application service that gathers appraisal data, executes valuation,
/// persists the result, and maps the output to DTOs.
/// </summary>
public sealed class ValuationApplicationService : IValuationApplicationService
{
    private readonly IAppraisalQueryService _appraisalQueryService;
    private readonly IValuationEngine _valuationEngine;
    private readonly IValuationRunRepository _valuationRunRepository;

    /// <summary>
    /// Initializes a new instance of the <see cref="ValuationApplicationService"/> class.
    /// </summary>
    public ValuationApplicationService(
        IAppraisalQueryService appraisalQueryService,
        IValuationEngine valuationEngine,
        IValuationRunRepository valuationRunRepository)
    {
        _appraisalQueryService = appraisalQueryService;
        _valuationEngine = valuationEngine;
        _valuationRunRepository = valuationRunRepository;
    }

    /// <inheritdoc />
    public async Task<ValuationResultDto> RunAsync(Guid appraisalId, CancellationToken ct)
    {
        SubjectVehicle subject = await _appraisalQueryService.GetSubjectVehicleAsync(appraisalId, ct);
        var conditionScores = await _appraisalQueryService.GetConditionScoresAsync(appraisalId, ct);
        var comparables = await _appraisalQueryService.GetComparableSalesAsync(appraisalId, ct);

        var input = new ValuationInput(
            Subject: subject,
            ConditionScores: conditionScores,
            Comparables: comparables,
            SegmentCode: "default",
            EngineVersion: ValuationVersions.EngineVersion,
            RulesetVersion: ValuationVersions.RulesetVersion,
            RubricVersion: ValuationVersions.RubricVersion);

        ValuationResult result = _valuationEngine.Run(input);

        await _valuationRunRepository.SaveAsync(appraisalId, result, ct);

        return new ValuationResultDto(
            result.Status,
            result.FinalValue,
            result.LowValue,
            result.HighValue,
            result.Confidence0To1,
            result.EngineVersion,
            result.RubricVersion,
            result.RulesetVersion,
            result.Trace
                .Select(x => new ValuationTraceLineDto(
                    x.SortOrder,
                    x.Type,
                    x.Key,
                    x.Amount,
                    x.Factor,
                    x.Message,
                    x.EvidenceRef))
                .ToList());
    }
}