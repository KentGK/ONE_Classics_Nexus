using System.Collections.Generic;
using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Application.Valuation.DTOs;

/// <summary>
/// Application-layer DTO for the completed valuation result.
/// </summary>
/// <param name="Status">The valuation status.</param>
/// <param name="FinalValue">The central value indication.</param>
/// <param name="LowValue">The low-end value indication.</param>
/// <param name="HighValue">The high-end value indication.</param>
/// <param name="Confidence0To1">The confidence score.</param>
/// <param name="EngineVersion">The engine version used.</param>
/// <param name="RubricVersion">The rubric version used.</param>
/// <param name="RulesetVersion">The ruleset version used.</param>
/// <param name="Trace">The valuation trace lines.</param>
public sealed record ValuationResultDto(
    ValuationStatus Status,
    decimal FinalValue,
    decimal LowValue,
    decimal HighValue,
    decimal Confidence0To1,
    string EngineVersion,
    string RubricVersion,
    string RulesetVersion,
    IReadOnlyList<ValuationTraceLineDto> Trace
);