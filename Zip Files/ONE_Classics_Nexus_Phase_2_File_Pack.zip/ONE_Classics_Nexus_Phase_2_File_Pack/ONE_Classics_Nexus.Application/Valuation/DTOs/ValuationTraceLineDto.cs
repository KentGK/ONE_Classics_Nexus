namespace ONE_Classics_Nexus.Application.Valuation.DTOs;

/// <summary>
/// Application-layer DTO for a valuation trace line.
/// </summary>
/// <param name="SortOrder">The trace order.</param>
/// <param name="Type">The trace line type.</param>
/// <param name="Key">The trace key.</param>
/// <param name="Amount">Optional numeric amount.</param>
/// <param name="Factor">Optional factor.</param>
/// <param name="Message">Human-readable message.</param>
/// <param name="EvidenceRef">Optional evidence reference.</param>
public sealed record ValuationTraceLineDto(
    int SortOrder,
    string Type,
    string Key,
    decimal? Amount,
    decimal? Factor,
    string Message,
    string? EvidenceRef
);