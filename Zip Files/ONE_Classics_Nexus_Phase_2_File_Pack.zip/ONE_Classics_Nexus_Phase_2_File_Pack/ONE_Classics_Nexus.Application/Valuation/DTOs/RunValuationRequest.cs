using System;

namespace ONE_Classics_Nexus.Application.Valuation.DTOs;

/// <summary>
/// Represents an application-layer request to run valuation for an appraisal.
/// </summary>
/// <param name="AppraisalId">The appraisal identifier to value.</param>
public sealed record RunValuationRequest(Guid AppraisalId);