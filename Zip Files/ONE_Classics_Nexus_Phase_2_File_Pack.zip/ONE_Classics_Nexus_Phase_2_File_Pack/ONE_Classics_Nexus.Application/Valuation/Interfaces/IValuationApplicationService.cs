using System;
using System.Threading;
using System.Threading.Tasks;
using ONE_Classics_Nexus.Application.Valuation.DTOs;

namespace ONE_Classics_Nexus.Application.Valuation.Interfaces;

/// <summary>
/// Orchestrates application-layer valuation execution.
/// </summary>
public interface IValuationApplicationService
{
    /// <summary>
    /// Runs valuation for the specified appraisal.
    /// </summary>
    Task<ValuationResultDto> RunAsync(Guid appraisalId, CancellationToken ct);
}