using System;
using System.Threading;
using System.Threading.Tasks;
using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Application.Valuation.Interfaces;

/// <summary>
/// Persists completed valuation runs and trace lines.
/// </summary>
public interface IValuationRunRepository
{
    /// <summary>
    /// Saves a completed valuation result for an appraisal.
    /// </summary>
    Task SaveAsync(Guid appraisalId, ValuationResult result, CancellationToken ct);
}