using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Application.Valuation.Interfaces;

/// <summary>
/// Provides read access to appraisal data needed for valuation execution.
/// </summary>
public interface IAppraisalQueryService
{
    /// <summary>
    /// Gets the subject vehicle for an appraisal.
    /// </summary>
    Task<SubjectVehicle> GetSubjectVehicleAsync(Guid appraisalId, CancellationToken ct);

    /// <summary>
    /// Gets the condition scores for an appraisal.
    /// </summary>
    Task<IReadOnlyList<ConditionScore>> GetConditionScoresAsync(Guid appraisalId, CancellationToken ct);

    /// <summary>
    /// Gets the comparable sales for an appraisal.
    /// </summary>
    Task<IReadOnlyList<ComparableSale>> GetComparableSalesAsync(Guid appraisalId, CancellationToken ct);
}