using System;
using System.Collections.Generic;
using System.Linq;
using ONE_Classics_Nexus.Domain.Valuation.Abstractions;
using ONE_Classics_Nexus.Domain.Valuation.Models;
using ONE_Classics_Nexus.Domain.Valuation.Rules;

namespace ONE_Classics_Nexus.Domain.Valuation.Engines;

/// <summary>
/// Default deterministic confidence engine.
/// </summary>
public sealed class DefaultConfidenceEngine : IConfidenceEngine
{
    /// <inheritdoc />
    public decimal CalculateConfidence0To1(
        IReadOnlyList<AdjustedComparable> adjustedComparables,
        IReadOnlyList<ConditionScore> conditionScores)
    {
        decimal compCountScore = Math.Min(1m, adjustedComparables.Count / 5m);

        decimal avgSimilarity = adjustedComparables.Count == 0
            ? 0m
            : adjustedComparables.Average(x => x.SimilarityScore0To1);

        decimal inspectionCompleteness = Math.Min(
            1m,
            conditionScores
                .Where(x => x.Weight0To1 > 0m)
                .Select(x => x.SystemKey)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count() / (decimal)ValuationRuleConstants.ExpectedSystemCount);

        decimal confidence =
            (compCountScore * 0.35m) +
            (avgSimilarity * 0.40m) +
            (inspectionCompleteness * 0.25m);

        return Clamp(confidence, 0m, 1m);
    }

    /// <summary>
    /// Clamps a value to the specified minimum and maximum.
    /// </summary>
    private static decimal Clamp(decimal value, decimal min, decimal max)
        => Math.Min(max, Math.Max(min, value));
}