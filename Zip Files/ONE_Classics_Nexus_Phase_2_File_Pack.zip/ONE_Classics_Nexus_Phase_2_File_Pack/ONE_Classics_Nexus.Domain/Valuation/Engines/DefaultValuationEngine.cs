using System.Collections.Generic;
using System.Linq;
using ONE_Classics_Nexus.Domain.Valuation.Abstractions;
using ONE_Classics_Nexus.Domain.Valuation.Models;
using ONE_Classics_Nexus.Domain.Valuation.Rules;

namespace ONE_Classics_Nexus.Domain.Valuation.Engines;

/// <summary>
/// Orchestrates the full default valuation pipeline and emits an auditable trace.
/// </summary>
public sealed class DefaultValuationEngine : IValuationEngine
{
    private readonly IConditionEngine _conditionEngine;
    private readonly IComparableEngine _comparableEngine;
    private readonly IMarketEngine _marketEngine;
    private readonly IConfidenceEngine _confidenceEngine;

    /// <summary>
    /// Initializes a new instance of the <see cref="DefaultValuationEngine"/> class.
    /// </summary>
    public DefaultValuationEngine(
        IConditionEngine conditionEngine,
        IComparableEngine comparableEngine,
        IMarketEngine marketEngine,
        IConfidenceEngine confidenceEngine)
    {
        _conditionEngine = conditionEngine;
        _comparableEngine = comparableEngine;
        _marketEngine = marketEngine;
        _confidenceEngine = confidenceEngine;
    }

    /// <inheritdoc />
    public ValuationResult Run(ValuationInput input)
    {
        var trace = new List<ValuationTraceLine>();
        int order = 1;

        if (input.Comparables is null || input.Comparables.Count == 0)
        {
            trace.Add(new ValuationTraceLine(
                order++,
                "Error",
                "Comparables",
                null,
                null,
                "No comparable sales were supplied.",
                null));

            return new ValuationResult(
                ValuationStatus.InsufficientData,
                0m,
                0m,
                0m,
                0m,
                input.EngineVersion,
                input.RubricVersion,
                input.RulesetVersion,
                trace);
        }

        decimal conditionIndex = _conditionEngine.CalculateConditionIndex0To100(input.ConditionScores);

        trace.Add(new ValuationTraceLine(
            order++,
            "Info",
            "ConditionIndex",
            conditionIndex,
            null,
            $"Condition index calculated at {conditionIndex:0.00}/100.",
            null));

        var adjusted = _comparableEngine.AdjustComparables(input.Subject, input.Comparables, conditionIndex);
        var usable = adjusted.Where(x => x.SimilarityScore0To1 > 0m).ToList();

        if (usable.Count == 0)
        {
            trace.Add(new ValuationTraceLine(
                order++,
                "Error",
                "UsableComparables",
                null,
                null,
                "No usable comparables remained after similarity scoring.",
                null));

            return new ValuationResult(
                ValuationStatus.InsufficientData,
                0m,
                0m,
                0m,
                0m,
                input.EngineVersion,
                input.RubricVersion,
                input.RulesetVersion,
                trace);
        }

        foreach (var comp in usable.OrderByDescending(x => x.SimilarityScore0To1))
        {
            trace.Add(new ValuationTraceLine(
                order++,
                "Comparable",
                comp.Comparable.ComparableId.ToString(),
                comp.AdjustedPrice,
                comp.SimilarityScore0To1,
                $"{comp.Comparable.Year} {comp.Comparable.Make} {comp.Comparable.Model} adjusted to {comp.AdjustedPrice:C}.",
                comp.Comparable.Url));
        }

        decimal totalWeight = usable.Sum(x => x.SimilarityScore0To1);
        decimal weightedValue = usable.Sum(x => x.AdjustedPrice * x.SimilarityScore0To1) / totalWeight;
        decimal marketAdjustedValue = _marketEngine.ApplyMarketLayer(weightedValue, input);
        decimal confidence = _confidenceEngine.CalculateConfidence0To1(usable, input.ConditionScores);

        decimal rangeWidthPct = ValuationRuleConstants.BaseRangeWidthPct +
                                ((1m - confidence) * ValuationRuleConstants.VariableRangeWidthPct);

        decimal low = marketAdjustedValue * (1m - rangeWidthPct);
        decimal high = marketAdjustedValue * (1m + rangeWidthPct);

        trace.Add(new ValuationTraceLine(
            order++,
            "Info",
            "WeightedIndication",
            weightedValue,
            null,
            "Weighted comparable indication calculated.",
            null));

        trace.Add(new ValuationTraceLine(
            order++,
            "Info",
            "MarketAdjustedValue",
            marketAdjustedValue,
            null,
            "Market layer applied.",
            null));

        trace.Add(new ValuationTraceLine(
            order++,
            "Info",
            "Confidence",
            null,
            confidence,
            $"Confidence calculated at {confidence:0.0000}.",
            null));

        trace.Add(new ValuationTraceLine(
            order++,
            "Info",
            "RangeWidthPct",
            null,
            rangeWidthPct,
            $"Value range width percentage = {rangeWidthPct:P2}.",
            null));

        return new ValuationResult(
            ValuationStatus.Success,
            decimal.Round(marketAdjustedValue, 0),
            decimal.Round(low, 0),
            decimal.Round(high, 0),
            decimal.Round(confidence, 4),
            input.EngineVersion,
            input.RubricVersion,
            input.RulesetVersion,
            trace);
    }
}