using ONE_Classics_Nexus.Domain.Valuation.Abstractions;
using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Domain.Valuation.Engines;

/// <summary>
/// Default market engine.
/// </summary>
/// <remarks>
/// This version is intentionally neutral and provides the extension point
/// for future market momentum, liquidity, geography, venue, and macro-cycle logic.
/// </remarks>
public sealed class DefaultMarketEngine : IMarketEngine
{
    /// <inheritdoc />
    public decimal ApplyMarketLayer(decimal baseValue, ValuationInput input)
    {
        _ = input;
        return baseValue;
    }
}