using System;
using System.Collections.Generic;
using ONE_Classics_Nexus.Domain.Valuation.Abstractions;
using ONE_Classics_Nexus.Domain.Valuation.Models;
using ONE_Classics_Nexus.Domain.Valuation.Rules;

namespace ONE_Classics_Nexus.Domain.Valuation.Engines;

/// <summary>
/// Default deterministic comparable adjustment engine.
/// </summary>
public sealed class DefaultComparableEngine : IComparableEngine
{
    private readonly ISimilarityEngine _similarityEngine;

    /// <summary>
    /// Initializes a new instance of the <see cref="DefaultComparableEngine"/> class.
    /// </summary>
    /// <param name="similarityEngine">The similarity engine used to score comparables.</param>
    public DefaultComparableEngine(ISimilarityEngine similarityEngine)
    {
        _similarityEngine = similarityEngine;
    }

    /// <inheritdoc />
    public IReadOnlyList<AdjustedComparable> AdjustComparables(
        SubjectVehicle subject,
        IReadOnlyList<ComparableSale> comparables,
        decimal subjectConditionIndex0To100)
    {
        var results = new List<AdjustedComparable>();

        foreach (var comp in comparables)
        {
            decimal similarity = _similarityEngine.CalculateSimilarity0To1(subject, comp);
            var adjustments = new List<ComparableAdjustment>();
            decimal adjusted = comp.SalePrice;

            decimal timeAdjustment = CalculateTimeAdjustment(comp);
            if (timeAdjustment != 0m)
            {
                adjustments.Add(new ComparableAdjustment(
                    "time",
                    timeAdjustment,
                    "Market time normalization to current date.",
                    comp.Url));

                adjusted += timeAdjustment;
            }

            decimal mileageAdjustment = CalculateMileageAdjustment(subject, comp);
            if (mileageAdjustment != 0m)
            {
                adjustments.Add(new ComparableAdjustment(
                    "mileage",
                    mileageAdjustment,
                    "Mileage normalization between subject and comparable.",
                    comp.Url));

                adjusted += mileageAdjustment;
            }

            // Future enhancement:
            // Introduce condition, originality, equipment, venue, and geography adjustments here.
            _ = subjectConditionIndex0To100;

            results.Add(new AdjustedComparable(
                comp,
                similarity,
                adjustments,
                adjusted));
        }

        return results;
    }

    /// <summary>
    /// Calculates the default time adjustment based on sale age in months.
    /// </summary>
    private static decimal CalculateTimeAdjustment(ComparableSale comp)
    {
        DateTime asOfUtc = DateTime.UtcNow;
        int months = Math.Max(
            0,
            ((asOfUtc.Year - comp.SaleDateUtc.Year) * 12) + (asOfUtc.Month - comp.SaleDateUtc.Month));

        return comp.SalePrice * ValuationRuleConstants.DefaultMonthlyTimeAdjustmentRate * months;
    }

    /// <summary>
    /// Calculates the default mileage adjustment.
    /// </summary>
    private static decimal CalculateMileageAdjustment(SubjectVehicle subject, ComparableSale comp)
    {
        if (!subject.Mileage.HasValue || !comp.Mileage.HasValue)
        {
            return 0m;
        }

        decimal delta = subject.Mileage.Value - comp.Mileage.Value;
        return delta * ValuationRuleConstants.DefaultMileageAdjustmentRatePerMile * -1m;
    }
}