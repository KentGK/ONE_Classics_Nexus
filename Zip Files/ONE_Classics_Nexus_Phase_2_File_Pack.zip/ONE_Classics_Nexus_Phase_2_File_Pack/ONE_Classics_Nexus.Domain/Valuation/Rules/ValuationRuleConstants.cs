namespace ONE_Classics_Nexus.Domain.Valuation.Rules;

/// <summary>
/// Holds deterministic constants used by the default valuation engine implementations.
/// </summary>
public static class ValuationRuleConstants
{
    /// <summary>
    /// The expected number of major inspection systems for completeness scoring.
    /// </summary>
    public const int ExpectedSystemCount = 12;

    /// <summary>
    /// The condition penalty applied per red-flagged system.
    /// </summary>
    public const decimal RedFlagPenaltyPerItem = 5m;

    /// <summary>
    /// The maximum total red flag condition penalty.
    /// </summary>
    public const decimal MaxRedFlagPenalty = 25m;

    /// <summary>
    /// The default monthly market time-adjustment rate.
    /// </summary>
    public const decimal DefaultMonthlyTimeAdjustmentRate = 0.0025m;

    /// <summary>
    /// The default mileage adjustment amount per mile.
    /// </summary>
    public const decimal DefaultMileageAdjustmentRatePerMile = 0.10m;

    /// <summary>
    /// The minimum valuation range width.
    /// </summary>
    public const decimal BaseRangeWidthPct = 0.05m;

    /// <summary>
    /// The variable portion of range width driven by confidence.
    /// </summary>
    public const decimal VariableRangeWidthPct = 0.15m;
}