namespace ONE_Classics_Nexus.Domain.Valuation.Versioning;

/// <summary>
/// Centralizes version identifiers for the default valuation stack.
/// </summary>
public static class ValuationVersions
{
    /// <summary>
    /// The default engine version identifier.
    /// </summary>
    public const string EngineVersion = "OCN-VAL-1.0.0";

    /// <summary>
    /// The default ruleset version identifier.
    /// </summary>
    public const string RulesetVersion = "OCN-RULES-1.0.0";

    /// <summary>
    /// The default rubric version identifier.
    /// </summary>
    public const string RubricVersion = "OCN-RUBRIC-1.0.0";
}