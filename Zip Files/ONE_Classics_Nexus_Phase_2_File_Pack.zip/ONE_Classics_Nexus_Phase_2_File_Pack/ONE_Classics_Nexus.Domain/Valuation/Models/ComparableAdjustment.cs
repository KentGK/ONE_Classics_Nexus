namespace ONE_Classics_Nexus.Domain.Valuation.Models;

/// <summary>
/// Represents a single adjustment applied to a comparable sale.
/// </summary>
/// <param name="CategoryKey">The adjustment category key.</param>
/// <param name="Amount">The signed adjustment amount.</param>
/// <param name="Reason">The human-readable explanation for the adjustment.</param>
/// <param name="EvidenceRef">An optional evidence reference such as a URL or note reference.</param>
public sealed record ComparableAdjustment(
    string CategoryKey,
    decimal Amount,
    string Reason,
    string? EvidenceRef
);