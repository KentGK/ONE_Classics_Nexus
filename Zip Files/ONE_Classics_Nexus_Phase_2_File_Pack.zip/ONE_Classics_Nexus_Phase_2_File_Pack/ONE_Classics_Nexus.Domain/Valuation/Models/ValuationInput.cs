using System;
using System.Collections.Generic;

namespace ONE_Classics_Nexus.Domain.Valuation.Models;

/// <summary>
/// Represents the full set of inputs required to execute a valuation run.
/// </summary>
/// <param name="Subject">The subject vehicle being valued.</param>
/// <param name="ConditionScores">The inspection-derived condition scores for the subject.</param>
/// <param name="Comparables">The comparable sales used in the valuation run.</param>
/// <param name="SegmentCode">The segment or ruleset bucket for the subject vehicle.</param>
/// <param name="EngineVersion">The valuation engine version used for the run.</param>
/// <param name="RulesetVersion">The business ruleset version used for the run.</param>
/// <param name="RubricVersion">The inspection rubric version used for the run.</param>
public sealed record ValuationInput(
    SubjectVehicle Subject,
    IReadOnlyList<ConditionScore> ConditionScores,
    IReadOnlyList<ComparableSale> Comparables,
    string SegmentCode,
    string EngineVersion,
    string RulesetVersion,
    string RubricVersion
);