using System.Collections.Generic;

namespace ONE_Classics_Nexus.Domain.Valuation.Models;

/// <summary>
/// Represents the completed output of a valuation run.
/// </summary>
/// <param name="Status">The final valuation status.</param>
/// <param name="FinalValue">The central indicated value.</param>
/// <param name="LowValue">The low-end range indication.</param>
/// <param name="HighValue">The high-end range indication.</param>
/// <param name="Confidence0To1">The valuation confidence on a 0-1 scale.</param>
/// <param name="EngineVersion">The engine version used.</param>
/// <param name="RubricVersion">The rubric version used.</param>
/// <param name="RulesetVersion">The ruleset version used.</param>
/// <param name="Trace">The ordered valuation trace lines.</param>
public sealed record ValuationResult(
    ValuationStatus Status,
    decimal FinalValue,
    decimal LowValue,
    decimal HighValue,
    decimal Confidence0To1,
    string EngineVersion,
    string RubricVersion,
    string RulesetVersion,
    IReadOnlyList<ValuationTraceLine> Trace
);