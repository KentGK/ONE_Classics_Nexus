namespace ONE_Classics_Nexus.Domain.Valuation.Models;

/// <summary>
/// Represents a scored inspection system or subsystem used in valuation.
/// </summary>
/// <param name="SystemKey">The unique key for the scored system.</param>
/// <param name="Score0To10">The score on a 0-10 scale.</param>
/// <param name="Weight0To1">The weighting factor on a 0-1 scale.</param>
/// <param name="IsRedFlag">Indicates whether the score carries a valuation red flag.</param>
/// <param name="Notes">Optional notes supporting the score.</param>
public sealed record ConditionScore(
    string SystemKey,
    decimal Score0To10,
    decimal Weight0To1,
    bool IsRedFlag,
    string? Notes
);