using System;

namespace ONE_Classics_Nexus.Domain.Valuation.Models;

/// <summary>
/// Represents a normalized comparable sale record.
/// </summary>
/// <param name="ComparableId">The unique identifier of the comparable.</param>
/// <param name="Year">The model year of the comparable.</param>
/// <param name="Make">The make of the comparable.</param>
/// <param name="Model">The model of the comparable.</param>
/// <param name="Trim">The trim of the comparable, if known.</param>
/// <param name="BodyStyle">The body style of the comparable, if known.</param>
/// <param name="Engine">The engine description of the comparable, if known.</param>
/// <param name="Transmission">The transmission description of the comparable, if known.</param>
/// <param name="Drivetrain">The drivetrain description of the comparable, if known.</param>
/// <param name="Series">The series or sub-model of the comparable, if known.</param>
/// <param name="SalePrice">The normalized sale price of the comparable.</param>
/// <param name="SaleDateUtc">The sale date in UTC.</param>
/// <param name="Source">The source system or venue.</param>
/// <param name="Url">A supporting URL, if available.</param>
/// <param name="Mileage">The comparable mileage, if known.</param>
/// <param name="Venue">The selling venue, if known.</param>
/// <param name="Notes">Optional notes for the comparable.</param>
public sealed record ComparableSale(
    Guid ComparableId,
    int Year,
    string Make,
    string Model,
    string? Trim,
    string? BodyStyle,
    string? Engine,
    string? Transmission,
    string? Drivetrain,
    string? Series,
    decimal SalePrice,
    DateTime SaleDateUtc,
    string Source,
    string? Url,
    decimal? Mileage,
    string? Venue,
    string? Notes
);