namespace ONE_Classics_Nexus.Domain.Valuation.Models;

/// <summary>
/// Represents a single ordered trace line emitted during valuation.
/// </summary>
/// <param name="SortOrder">The display and persistence order of the trace line.</param>
/// <param name="Type">The trace line type such as Info, Error, or Comparable.</param>
/// <param name="Key">A machine-readable trace key.</param>
/// <param name="Amount">An optional monetary or numeric amount.</param>
/// <param name="Factor">An optional factor or ratio.</param>
/// <param name="Message">The human-readable trace message.</param>
/// <param name="EvidenceRef">Optional evidence reference such as a URL or note key.</param>
public sealed record ValuationTraceLine(
    int SortOrder,
    string Type,
    string Key,
    decimal? Amount,
    decimal? Factor,
    string Message,
    string? EvidenceRef
);