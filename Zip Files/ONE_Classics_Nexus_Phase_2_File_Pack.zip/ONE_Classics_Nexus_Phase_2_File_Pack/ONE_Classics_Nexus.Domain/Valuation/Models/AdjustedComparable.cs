using System.Collections.Generic;

namespace ONE_Classics_Nexus.Domain.Valuation.Models;

/// <summary>
/// Represents a comparable after similarity scoring and price adjustments.
/// </summary>
/// <param name="Comparable">The underlying comparable sale.</param>
/// <param name="SimilarityScore0To1">The similarity score on a 0-1 scale.</param>
/// <param name="Adjustments">The collection of individual adjustments applied.</param>
/// <param name="AdjustedPrice">The final adjusted comparable price.</param>
public sealed record AdjustedComparable(
    ComparableSale Comparable,
    decimal SimilarityScore0To1,
    IReadOnlyList<ComparableAdjustment> Adjustments,
    decimal AdjustedPrice
);