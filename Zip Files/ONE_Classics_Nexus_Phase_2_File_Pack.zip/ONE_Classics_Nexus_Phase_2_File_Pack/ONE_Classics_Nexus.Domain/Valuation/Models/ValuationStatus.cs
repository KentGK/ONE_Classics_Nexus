namespace ONE_Classics_Nexus.Domain.Valuation.Models;

/// <summary>
/// Represents the outcome state of a valuation run.
/// </summary>
public enum ValuationStatus
{
    /// <summary>
    /// The valuation has not been executed yet.
    /// </summary>
    Pending = 0,

    /// <summary>
    /// The valuation completed successfully.
    /// </summary>
    Success = 1,

    /// <summary>
    /// The valuation could not be completed because required data was insufficient.
    /// </summary>
    InsufficientData = 2,

    /// <summary>
    /// The valuation completed but requires human review.
    /// </summary>
    NeedsReview = 3,

    /// <summary>
    /// The valuation run failed in a known way.
    /// </summary>
    Failed = 4,

    /// <summary>
    /// The valuation run encountered an unexpected error condition.
    /// </summary>
    Error = 5
}