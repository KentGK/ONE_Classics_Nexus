using System;

namespace ONE_Classics_Nexus.Domain.Valuation.Models;

/// <summary>
/// Represents the subject vehicle being appraised.
/// </summary>
/// <param name="VehicleId">The unique identifier of the vehicle.</param>
/// <param name="Year">The model year.</param>
/// <param name="Make">The manufacturer name.</param>
/// <param name="Model">The model name.</param>
/// <param name="Trim">The trim designation, if known.</param>
/// <param name="BodyStyle">The body style classification, if known.</param>
/// <param name="Engine">The engine or engine family description, if known.</param>
/// <param name="Transmission">The transmission description, if known.</param>
/// <param name="Drivetrain">The drivetrain description, if known.</param>
/// <param name="Series">The series or sub-model bucket, if known.</param>
/// <param name="Mileage">The odometer reading or normalized mileage estimate, if known.</param>
/// <param name="Vin">The VIN, if known.</param>
public sealed record SubjectVehicle(
    Guid VehicleId,
    int Year,
    string Make,
    string Model,
    string? Trim,
    string? BodyStyle,
    string? Engine,
    string? Transmission,
    string? Drivetrain,
    string? Series,
    decimal? Mileage,
    string? Vin
);