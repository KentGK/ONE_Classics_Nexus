using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Domain.Valuation.Abstractions;

/// <summary>
/// Calculates similarity between a subject vehicle and a comparable sale.
/// </summary>
public interface ISimilarityEngine
{
    /// <summary>
    /// Calculates a similarity score on a 0-1 scale.
    /// </summary>
    /// <param name="subject">The subject vehicle.</param>
    /// <param name="comparable">The comparable sale.</param>
    /// <returns>The similarity score.</returns>
    decimal CalculateSimilarity0To1(SubjectVehicle subject, ComparableSale comparable);
}