using System.Collections.Generic;
using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Domain.Valuation.Abstractions;

/// <summary>
/// Calculates a normalized condition index from scored inspection inputs.
/// </summary>
public interface IConditionEngine
{
    /// <summary>
    /// Calculates a condition index on a 0-100 scale.
    /// </summary>
    /// <param name="scores">The scored inspection systems.</param>
    /// <returns>The normalized condition index.</returns>
    decimal CalculateConditionIndex0To100(IReadOnlyList<ConditionScore> scores);
}