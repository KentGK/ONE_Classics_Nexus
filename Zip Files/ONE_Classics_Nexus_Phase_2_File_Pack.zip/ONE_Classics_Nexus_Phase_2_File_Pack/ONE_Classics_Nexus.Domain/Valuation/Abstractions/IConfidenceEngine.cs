using System.Collections.Generic;
using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Domain.Valuation.Abstractions;

/// <summary>
/// Calculates confidence for a valuation run.
/// </summary>
public interface IConfidenceEngine
{
    /// <summary>
    /// Calculates valuation confidence on a 0-1 scale.
    /// </summary>
    /// <param name="adjustedComparables">The adjusted comparable set.</param>
    /// <param name="conditionScores">The subject condition scores.</param>
    /// <returns>The confidence score.</returns>
    decimal CalculateConfidence0To1(
        IReadOnlyList<AdjustedComparable> adjustedComparables,
        IReadOnlyList<ConditionScore> conditionScores);
}