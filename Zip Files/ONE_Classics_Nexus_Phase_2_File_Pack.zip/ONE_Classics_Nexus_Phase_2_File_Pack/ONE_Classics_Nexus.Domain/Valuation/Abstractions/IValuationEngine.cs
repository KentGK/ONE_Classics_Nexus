using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Domain.Valuation.Abstractions;

/// <summary>
/// Executes the full valuation pipeline.
/// </summary>
public interface IValuationEngine
{
    /// <summary>
    /// Runs a complete valuation using the supplied input.
    /// </summary>
    /// <param name="input">The normalized valuation input.</param>
    /// <returns>The completed valuation result.</returns>
    ValuationResult Run(ValuationInput input);
}