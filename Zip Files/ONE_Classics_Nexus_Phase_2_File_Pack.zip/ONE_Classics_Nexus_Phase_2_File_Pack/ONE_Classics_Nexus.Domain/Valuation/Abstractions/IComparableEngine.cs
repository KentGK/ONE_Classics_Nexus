using System.Collections.Generic;
using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Domain.Valuation.Abstractions;

/// <summary>
/// Normalizes and adjusts comparable sales for use in valuation.
/// </summary>
public interface IComparableEngine
{
    /// <summary>
    /// Adjusts the supplied comparables against the subject.
    /// </summary>
    /// <param name="subject">The subject vehicle.</param>
    /// <param name="comparables">The source comparables.</param>
    /// <param name="subjectConditionIndex0To100">The normalized subject condition index.</param>
    /// <returns>A list of adjusted comparables.</returns>
    IReadOnlyList<AdjustedComparable> AdjustComparables(
        SubjectVehicle subject,
        IReadOnlyList<ComparableSale> comparables,
        decimal subjectConditionIndex0To100);
}