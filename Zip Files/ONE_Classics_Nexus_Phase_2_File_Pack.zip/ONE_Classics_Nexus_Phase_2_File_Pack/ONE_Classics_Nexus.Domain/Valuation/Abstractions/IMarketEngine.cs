using ONE_Classics_Nexus.Domain.Valuation.Models;

namespace ONE_Classics_Nexus.Domain.Valuation.Abstractions;

/// <summary>
/// Applies market-level adjustments to a base valuation indication.
/// </summary>
public interface IMarketEngine
{
    /// <summary>
    /// Applies market-layer logic to a base value.
    /// </summary>
    /// <param name="baseValue">The pre-market indicated value.</param>
    /// <param name="input">The full valuation input.</param>
    /// <returns>The market-adjusted value.</returns>
    decimal ApplyMarketLayer(decimal baseValue, ValuationInput input);
}