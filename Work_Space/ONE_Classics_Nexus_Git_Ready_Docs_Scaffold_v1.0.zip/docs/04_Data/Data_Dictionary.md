# Data Dictionary

Canonical database definitions for Nexus.
