USE one_classics_nexus;

-- Canonical 12-system seed reference.
-- Store final reference-table inserts here when lookup tables are added.
