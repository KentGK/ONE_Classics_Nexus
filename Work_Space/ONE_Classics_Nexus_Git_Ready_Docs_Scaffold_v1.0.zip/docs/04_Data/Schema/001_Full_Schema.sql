CREATE DATABASE IF NOT EXISTS one_classics_nexus;
USE one_classics_nexus;

CREATE TABLE IF NOT EXISTS vehicles (
    vehicle_id CHAR(36) PRIMARY KEY,
    vin VARCHAR(50) UNIQUE,
    year INT NOT NULL,
    make VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    trim VARCHAR(100) NULL,
    body_style VARCHAR(100) NULL,
    engine VARCHAR(100) NULL,
    transmission VARCHAR(100) NULL,
    drivetrain VARCHAR(100) NULL,
    mileage DECIMAL(10,2) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL
);

CREATE TABLE IF NOT EXISTS appraisals (
    appraisal_id CHAR(36) PRIMARY KEY,
    vehicle_id CHAR(36) NOT NULL,
    appraisal_number VARCHAR(50) NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'Draft',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL,
    CONSTRAINT fk_appraisals_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id)
);

CREATE TABLE IF NOT EXISTS inspections (
    inspection_id CHAR(36) PRIMARY KEY,
    appraisal_id CHAR(36) NOT NULL,
    inspection_type VARCHAR(50) NOT NULL,
    vehicle_type VARCHAR(50) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL,
    CONSTRAINT fk_inspections_appraisal FOREIGN KEY (appraisal_id) REFERENCES appraisals(appraisal_id)
);

CREATE TABLE IF NOT EXISTS condition_scores (
    condition_score_id CHAR(36) PRIMARY KEY,
    inspection_id CHAR(36) NULL,
    appraisal_id CHAR(36) NOT NULL,
    system_number INT NOT NULL,
    system_key VARCHAR(75) NOT NULL,
    system_code VARCHAR(50) NOT NULL,
    score_0_to_5 DECIMAL(3,2) NOT NULL,
    is_red_flag BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL,
    CONSTRAINT fk_condition_scores_appraisal FOREIGN KEY (appraisal_id) REFERENCES appraisals(appraisal_id),
    CONSTRAINT fk_condition_scores_inspection FOREIGN KEY (inspection_id) REFERENCES inspections(inspection_id),
    CONSTRAINT ck_condition_scores_system_number CHECK (system_number BETWEEN 1 AND 12),
    CONSTRAINT ck_condition_scores_score CHECK (score_0_to_5 BETWEEN 0.00 AND 5.00)
);

CREATE INDEX ix_condition_scores_appraisal ON condition_scores(appraisal_id);
CREATE INDEX ix_condition_scores_system ON condition_scores(system_number, system_key);

CREATE TABLE IF NOT EXISTS comparable_sales (
    comparable_id CHAR(36) PRIMARY KEY,
    appraisal_id CHAR(36) NOT NULL,
    year INT NULL,
    make VARCHAR(100) NULL,
    model VARCHAR(100) NULL,
    trim VARCHAR(100) NULL,
    sale_price DECIMAL(12,2) NULL,
    asking_price DECIMAL(12,2) NULL,
    sale_date DATE NULL,
    source VARCHAR(100) NULL,
    source_listing_url TEXT NULL,
    overall_condition_score DECIMAL(3,2) NULL,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL,
    CONSTRAINT fk_comparable_sales_appraisal FOREIGN KEY (appraisal_id) REFERENCES appraisals(appraisal_id)
);

CREATE TABLE IF NOT EXISTS valuation_runs (
    valuation_run_id CHAR(36) PRIMARY KEY,
    appraisal_id CHAR(36) NOT NULL,
    valuation_status VARCHAR(50) NOT NULL,
    value_low DECIMAL(12,2) NULL,
    value_mid DECIMAL(12,2) NULL,
    value_high DECIMAL(12,2) NULL,
    confidence_score DECIMAL(5,2) NULL,
    executed_at_utc DATETIME NOT NULL DEFAULT UTC_TIMESTAMP(),
    CONSTRAINT fk_valuation_runs_appraisal FOREIGN KEY (appraisal_id) REFERENCES appraisals(appraisal_id)
);
