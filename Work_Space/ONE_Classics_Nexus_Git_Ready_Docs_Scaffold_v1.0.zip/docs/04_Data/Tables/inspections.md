# inspections

Inspection header record linked to one appraisal.
