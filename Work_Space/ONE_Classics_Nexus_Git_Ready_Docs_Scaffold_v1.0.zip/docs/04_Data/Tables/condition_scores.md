# condition_scores

Authoritative section-level condition score table.

| Column | Rule |
|---|---|
| system_number | Fixed 1–12 canonical order |
| system_key | Canonical snake_case key |
| score_0_to_5 | Decimal score from 0.00 to 5.00 |
| is_red_flag | Critical issue indicator |
| notes | Appraiser notes |
