# appraisals

Appraisal case record linked to one vehicle.
