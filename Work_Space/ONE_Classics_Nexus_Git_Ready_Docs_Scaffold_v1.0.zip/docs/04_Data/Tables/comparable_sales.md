# comparable_sales

Comparable market data linked to one appraisal.
