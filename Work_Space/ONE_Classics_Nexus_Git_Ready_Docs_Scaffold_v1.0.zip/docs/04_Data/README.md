# Data

DBA-owned source of truth for schema, ERD, table specs, views, seed data, and data dictionary.
