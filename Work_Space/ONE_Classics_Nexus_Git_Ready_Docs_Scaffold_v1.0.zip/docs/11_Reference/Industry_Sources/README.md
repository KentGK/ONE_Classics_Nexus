# Industry Sources
