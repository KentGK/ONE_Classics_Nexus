# External Research
