# Inspection UI Specification

The inspection UI must display all 12 systems, support 0–5 scoring, red flag checkbox, and notes per system.
