# Colors

Primary Nexus theme color: `#0E2841`.
