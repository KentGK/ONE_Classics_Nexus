# Requirements

BA-owned requirements, SRS versions, traceability, use cases, user stories, and glossary.
