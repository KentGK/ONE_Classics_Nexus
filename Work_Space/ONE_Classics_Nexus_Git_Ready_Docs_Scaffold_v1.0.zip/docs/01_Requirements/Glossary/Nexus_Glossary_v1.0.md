# ONE Classics Nexus — Glossary

| Term | Description |
|---|---|
| ONE Classics | Entity owner of the Nexus solution. |
| Nexus | Marketable vehicle inspection and valuation solution. |
| Nexus Project | Project developing the Nexus solution. |
| AVM | Automated Valuation Model. |
| Condition Index | Normalized 0–100 score derived from weighted 12-system scores. |
