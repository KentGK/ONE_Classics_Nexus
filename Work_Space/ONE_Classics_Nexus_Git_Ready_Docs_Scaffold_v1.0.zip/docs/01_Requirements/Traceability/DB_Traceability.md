# Database Traceability

| Table | Requirement | Repository | Test |
|---|---|---|---|
| condition_scores | FR-003, FR-004 | InspectionRepository | Inspection integration tests |
