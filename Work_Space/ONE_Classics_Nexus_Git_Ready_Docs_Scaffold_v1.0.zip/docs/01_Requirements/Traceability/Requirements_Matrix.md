# Requirements Traceability Matrix

| Requirement ID | DDS Section | DB Object | API Endpoint | Engine/Test |
|---|---|---|---|---|
| FR-003 | Inspection Design | condition_scores | `/api/inspections` | Inspection tests |
| FR-005 | Valuation Design | valuation_runs | `/api/appraisals/{appraisalId}/valuation/run` | Golden valuation test |
