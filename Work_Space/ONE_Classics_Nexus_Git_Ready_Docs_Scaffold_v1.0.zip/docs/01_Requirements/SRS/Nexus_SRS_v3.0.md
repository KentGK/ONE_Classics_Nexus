# ONE Classics Nexus — Software Requirements Specification

Version: 3.0  
Status: Starter Draft

## 1. Purpose

Define the functional and non-functional requirements for the ONE Classics Nexus solution.

## 2. Scope

Nexus supports vehicle intake, appraisal creation, 12-system inspection, comparable sales, deterministic AVM valuation, valuation traceability, confidence scoring, and reporting.

## 3. Vehicle Types

Supported vehicle types:
- Standard Vehicle
- Custom Vehicle
- Classic Vehicle

Vehicle type must be configurable and must not change the canonical 12-system mapping.

## 4. Canonical 12-System Model

| # | System | Code | Key |
|---:|---|---|---|
| 1 | Body & Exterior | BODY_EXT | body_exterior |
| 2 | Frame & Structure | FRAME_STRUCT | frame_structure |
| 3 | Engine / Powertrain | POWERTRAIN | powertrain |
| 4 | Transmission & Driveline | TRANS_DRIVE | transmission_driveline |
| 5 | Suspension & Steering | SUS_STEER | suspension_steering |
| 6 | Braking System | BRAKE_SYS | braking_system |
| 7 | Electrical System | ELEC_SYS | electrical_system |
| 8 | Interior | INTERIOR | interior |
| 9 | Wheels & Tires | WHEEL_TIRE | wheels_tires |
| 10 | Trim, Glass & Details | TRIM_GLASS | trim_glass_details |
| 11 | Documentation & Provenance | DOC_PROV | documentation_provenance |
| 12 | Road Test & Functional | ROAD_FUNC | road_test_functional |

## 5. Functional Requirements

| ID | Requirement |
|---|---|
| FR-001 | The system shall manage vehicles. |
| FR-002 | The system shall manage appraisals linked to vehicles. |
| FR-003 | The system shall capture 12-system inspection scores. |
| FR-004 | The system shall store section-level scores in `condition_scores`. |
| FR-005 | The system shall execute deterministic valuation runs. |
| FR-006 | The system shall produce valuation traceability records. |
| FR-007 | The system shall support confidence scoring. |
| FR-008 | The system shall support red flag rules and adjustments. |

## 6. Non-Functional Requirements

| ID | Requirement |
|---|---|
| NFR-001 | Same valuation inputs must produce the same valuation outputs. |
| NFR-002 | All valuation outputs must be explainable. |
| NFR-003 | Schema, API, engine, and test artifacts must be traceable to requirements. |
