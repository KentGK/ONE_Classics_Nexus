# Error Handling

Use consistent ProblemDetails responses for validation and server errors.
