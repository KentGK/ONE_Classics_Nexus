# DTOs

Document API request/response contracts here.
