# Valuation Endpoints

- POST `/api/appraisals/{appraisalId}/valuation/run`
- GET `/api/appraisals/{appraisalId}/valuation/runs`
