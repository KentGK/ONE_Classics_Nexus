# Appraisals Endpoints

- POST `/api/appraisals`
