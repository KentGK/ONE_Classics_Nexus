# Inspections Endpoints

- POST `/api/inspections`
