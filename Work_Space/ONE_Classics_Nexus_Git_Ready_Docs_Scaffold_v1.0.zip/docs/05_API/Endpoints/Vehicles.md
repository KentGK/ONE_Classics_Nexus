# Vehicles Endpoints

- POST `/api/vehicles`
- GET `/api/vehicles/{id}`
