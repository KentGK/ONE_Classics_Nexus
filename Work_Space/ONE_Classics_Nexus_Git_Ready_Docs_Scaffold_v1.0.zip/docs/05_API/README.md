# API

API contracts, endpoints, DTOs, error handling, and versioning.
