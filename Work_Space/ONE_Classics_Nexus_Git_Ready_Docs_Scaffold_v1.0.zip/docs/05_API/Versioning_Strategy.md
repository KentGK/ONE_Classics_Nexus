# API Versioning Strategy

Initial API version: v1.
