# ONE Classics Nexus — Documentation

This folder is the Git-ready documentation source for the ONE Classics Nexus solution.

## Documentation Rules

1. Requirements live in `01_Requirements`.
2. Architecture lives in `02_Architecture`.
3. Detailed design lives in `03_Design`.
4. Database schema lives only in `04_Data/Schema`.
5. API contracts live only in `05_API/OpenAPI`.
6. AVM math and valuation engine contracts live only in `06_Engine`.
7. Testing evidence and deterministic datasets live in `08_Testing_Quality`.
8. Deprecated or superseded documents move to `99_Archive`.

## Traceability Chain

SRS → DDS → DB → API → Engine → Tests

## Locked Nexus Rules

- The canonical 12-system model is fixed across Standard, Custom, and Classic vehicles.
- `condition_scores` is the authoritative section-level scoring table.
- Required score fields:
  - `system_number`
  - `system_key`
  - `score_0_to_5`
  - `is_red_flag`
  - `notes`
