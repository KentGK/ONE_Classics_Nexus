# ONE Classics Nexus — Project Roadmap

## Phase 1
Foundation: vehicles, appraisals, schema baseline, API basics.

## Phase 2
Inspection, condition scores, valuation engine foundation, WinForms integration.

## Phase 3
Reporting, investor readiness, advanced AVM, client workflows.
