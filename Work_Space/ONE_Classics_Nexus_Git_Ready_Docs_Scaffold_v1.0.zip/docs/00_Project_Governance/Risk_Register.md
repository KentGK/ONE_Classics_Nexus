# Risk Register

| ID | Risk | Impact | Probability | Mitigation | Status |
|---|---|---:|---:|---|---|
| RISK-001 | Schema drift between DB and code | High | Medium | Use `/04_Data/Schema` as source of truth | Open |
