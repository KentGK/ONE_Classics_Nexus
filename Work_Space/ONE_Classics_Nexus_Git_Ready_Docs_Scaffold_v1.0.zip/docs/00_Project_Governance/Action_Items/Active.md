# Active Action Items

| Priority | Item | Owner | Status |
|---:|---|---|---|
| 1 | Generate red_flag_rules SQL seed data | DBA/TA | Open |
| 2 | Create C# enums and models for red flags | TA/TL | Open |
| 3 | Implement RedFlagEngine for deterministic AVM integration | TL | Open |
