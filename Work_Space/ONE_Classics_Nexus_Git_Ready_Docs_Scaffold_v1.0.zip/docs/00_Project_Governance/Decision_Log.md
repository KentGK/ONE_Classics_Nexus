# Decision Log

| Date | Decision | Owner | Rationale | Impact |
|---|---|---|---|---|
| TBD | `condition_scores` is authoritative section score table | DBA/TA | Prevent score model drift | DB/API/Engine alignment |
