# Similarity Engine

Scores similarity between subject vehicle and comparable sales.
