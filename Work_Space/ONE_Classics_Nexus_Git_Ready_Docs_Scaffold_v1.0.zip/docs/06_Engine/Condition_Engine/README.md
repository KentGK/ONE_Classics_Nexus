# Condition Engine

Computes weighted 0–100 condition index from 12-system scores.
