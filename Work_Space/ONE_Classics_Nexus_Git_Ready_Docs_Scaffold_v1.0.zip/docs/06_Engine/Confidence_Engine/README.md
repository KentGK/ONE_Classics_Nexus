# Confidence Engine

Computes confidence score based on data completeness, comp count, and similarity strength.
