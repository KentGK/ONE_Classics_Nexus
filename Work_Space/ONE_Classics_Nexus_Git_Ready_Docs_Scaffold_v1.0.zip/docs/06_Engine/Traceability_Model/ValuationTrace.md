# Valuation Trace Model

Each valuation run should produce trace entries explaining inputs, factors, adjustments, and final output.
