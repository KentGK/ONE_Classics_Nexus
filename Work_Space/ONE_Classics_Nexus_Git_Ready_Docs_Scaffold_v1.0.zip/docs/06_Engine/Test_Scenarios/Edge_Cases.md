# AVM Edge Cases

- Missing condition score
- No comparable sales
- Red flag critical failure
- Low confidence due to incomplete data
