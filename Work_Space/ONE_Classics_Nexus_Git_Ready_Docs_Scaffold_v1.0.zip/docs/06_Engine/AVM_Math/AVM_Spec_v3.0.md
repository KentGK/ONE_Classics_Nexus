# AVM Math Specification v3.0

## Condition Index

`CI = SUM(score_0_to_5 × weight) × 20`

Weights must sum to 1.00.

## Standard Vehicle Weights

| Code | Weight |
|---|---:|
| BODY_EXT | 0.06 |
| FRAME_STRUCT | 0.10 |
| POWERTRAIN | 0.18 |
| TRANS_DRIVE | 0.14 |
| SUS_STEER | 0.10 |
| BRAKE_SYS | 0.10 |
| ELEC_SYS | 0.10 |
| INTERIOR | 0.04 |
| WHEEL_TIRE | 0.06 |
| TRIM_GLASS | 0.02 |
| DOC_PROV | 0.02 |
| ROAD_FUNC | 0.08 |

## Deterministic Rule

Same inputs must produce same outputs.
