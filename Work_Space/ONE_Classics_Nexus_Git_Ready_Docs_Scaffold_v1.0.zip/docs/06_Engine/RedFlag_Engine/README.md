# Red Flag Engine

Applies deterministic red flag adjustments after base condition scoring.
