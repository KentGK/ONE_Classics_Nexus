# Repositories

Repositories must map exactly to canonical database schema.
