# Design

DDS, sequence diagrams, component design, repository design, and design patterns.
