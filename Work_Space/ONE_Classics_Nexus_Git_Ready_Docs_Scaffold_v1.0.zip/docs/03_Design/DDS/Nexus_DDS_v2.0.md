# Detailed Design Specification

Version: 2.0

## Critical Design Rule

The valuation pipeline must read 12-system scores from `condition_scores` and produce valuation runs and trace output.
