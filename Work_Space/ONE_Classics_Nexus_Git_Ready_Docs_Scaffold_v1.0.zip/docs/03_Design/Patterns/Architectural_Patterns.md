# Architectural Patterns

- Layered architecture
- Repository pattern
- Deterministic engine contracts
- Traceable valuation output
