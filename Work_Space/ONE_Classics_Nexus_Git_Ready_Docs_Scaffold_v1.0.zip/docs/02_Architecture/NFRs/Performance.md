# Performance NFRs

Valuation execution target: less than 2 seconds for normal appraisal data.
