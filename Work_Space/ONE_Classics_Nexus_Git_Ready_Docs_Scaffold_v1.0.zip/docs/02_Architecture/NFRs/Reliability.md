# Reliability NFRs

Valuation outcomes must be deterministic and testable.
