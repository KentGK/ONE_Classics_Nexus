# Scalability NFRs

Support future vehicle types without altering the canonical 12-system mapping.
