# System Architecture

## Layers

- API
- Application
- Domain
- Infrastructure
- Core Engine
- WinForms UI
- Reporting
