# Logical Architecture

Nexus follows a layered architecture with isolated engine logic and repository-backed persistence.
