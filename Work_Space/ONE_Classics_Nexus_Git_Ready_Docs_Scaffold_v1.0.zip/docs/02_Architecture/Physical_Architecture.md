# Physical Architecture

Primary runtime components: .NET API, WinForms client, MariaDB database.
