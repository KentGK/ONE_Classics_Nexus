# Architecture

EA/TA-owned architecture documentation and diagrams.
