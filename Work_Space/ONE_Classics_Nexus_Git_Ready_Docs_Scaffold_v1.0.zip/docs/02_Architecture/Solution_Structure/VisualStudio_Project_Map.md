# Visual Studio Project Map

- ONE_Classics_Nexus.API
- ONE_Classics_Nexus.Application
- ONE_Classics_Nexus.Domain
- ONE_Classics_Nexus.Infrastructure
- ONE_Classics_Nexus.WinForms
- ONE_Classics_Nexus.Tests
