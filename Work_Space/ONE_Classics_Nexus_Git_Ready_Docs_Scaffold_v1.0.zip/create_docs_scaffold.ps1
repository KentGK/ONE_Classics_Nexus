# ONE Classics Nexus — Git-ready docs scaffold installer
# Run from solution root:
#   powershell -ExecutionPolicy Bypass -File .\create_docs_scaffold.ps1

$ErrorActionPreference = "Stop"

if (-not (Test-Path ".\docs")) {
    New-Item -ItemType Directory -Path ".\docs" | Out-Null
}

Write-Host "Docs scaffold should be copied from this package into the solution root."
Write-Host "Recommended command after unzip:"
Write-Host "  robocopy .\docs .\docs /E"
Write-Host "Then run:"
Write-Host "  git add docs"
Write-Host "  git commit -m `"Add Nexus documentation scaffold`""
