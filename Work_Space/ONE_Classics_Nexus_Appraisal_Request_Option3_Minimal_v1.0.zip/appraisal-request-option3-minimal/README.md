# ONE Classics Nexus — Option 3 Minimal Appraisal Request

This prototype implements the simplified **Guided Request Workspace** direction.

## Primary intake information

- Vehicle lookup and compact Vehicle summary.
- Client lookup.
- Optional Primary Contact with email and phone summary.
- Intended Users with add, edit, select, and remove behavior.

## Simplifications

The primary intake screen no longer displays:

- Multi-step navigation.
- Intended Use and value-definition details.
- Effective or completion dates.
- Scope narrative.
- Notes and attachments.
- Audit history and row version.
- Detailed lifecycle and conversion controls.

Those items are deferred to later review and Appraisal establishment. The Appraisal Request remains pre-appraisal intake data rather than the authoritative Appraisal record.

## Run locally

```bash
npm install
npm run dev -- --host 0.0.0.0 --port 4173 --strictPort
```

## Verify

```bash
npm run build
npm run test:sites
```
