import { useEffect, useMemo, useState } from "react";
import {
  FaHouse, FaCarSide, FaFileLines, FaClipboardCheck, FaTableList,
  FaChartColumn, FaGear, FaCircleQuestion, FaChevronDown, FaBars,
  FaPlus, FaFloppyDisk, FaPaperPlane, FaMagnifyingGlass, FaPen,
  FaTrashCan, FaCircleCheck, FaCircleExclamation, FaXmark,
  FaUser, FaBuilding, FaPhone, FaEnvelope, FaChevronRight
} from "react-icons/fa6";

const navItems = [
  [FaHouse, "Dashboard"], [FaCarSide, "Vehicles"], [FaFileLines, "Appraisal Requests"],
  [FaClipboardCheck, "Appraisals"], [FaTableList, "Inspections"], [FaTableList, "Comparables"],
  [FaChartColumn, "Valuation"], [FaFileLines, "Reports"], [FaGear, "Admin"]
];

const requests = [
  { number: "AR-2026-00418", client: "Smith Automotive Collection", vehicle: "1967 Ford Mustang GT", status: "Draft" },
  { number: "AR-2026-00417", client: "Miller Family Trust", vehicle: "1970 Dodge Challenger", status: "Under Review" },
  { number: "AR-2026-00416", client: "Hartwell Collection", vehicle: "1966 Chevrolet Corvette", status: "Submitted" }
];

const vehicles = [
  { id: "mustang", name: "1967 Ford Mustang GT", vin: "7R02S123456" },
  { id: "corvette", name: "1966 Chevrolet Corvette", vin: "194676S112233" },
  { id: "challenger", name: "1970 Dodge Challenger R/T", vin: "JS23U0B123456" }
];

const clients = {
  smith: {
    name: "Smith Automotive Collection",
    contacts: [
      { id: "john", name: "John Smith", email: "john.smith@smithauto.com", phone: "(248) 555-0100" },
      { id: "mary", name: "Mary Smith", email: "mary.smith@smithauto.com", phone: "(248) 555-0104" }
    ]
  },
  hartwell: {
    name: "Hartwell Collection",
    contacts: [{ id: "claire", name: "Claire Hartwell", email: "claire@hartwellcollection.com", phone: "(312) 555-0185" }]
  }
};

const initialUsers = [
  { id: 1, type: "Individual", name: "John Smith", relationship: "Owner", isClient: true },
  { id: 2, type: "Individual", name: "Mary Smith", relationship: "Family Member", isClient: false }
];

function Button({ icon: Icon, children, tone = "outline", disabled, onClick, className = "" }) {
  return <button className={`button ${tone} ${className}`} disabled={disabled} onClick={onClick}>{Icon && <Icon />}<span>{children}</span></button>;
}

function RuntimeDiagnostics() {
  const [errors,setErrors]=useState(0);
  useEffect(()=>{
    const original=console.error;
    const onError=()=>setErrors(value=>value+1);
    console.error=(...args)=>{onError();original(...args)};
    window.addEventListener("error",onError);
    window.addEventListener("unhandledrejection",onError);
    return()=>{console.error=original;window.removeEventListener("error",onError);window.removeEventListener("unhandledrejection",onError)};
  },[]);
  return <output style={{position:"absolute",width:1,height:1,padding:0,margin:-1,overflow:"hidden",clip:"rect(0,0,0,0)",whiteSpace:"nowrap",border:0}}>Application diagnostics: {errors} errors</output>;
}

function ShellHeader() {
  return <><RuntimeDiagnostics/><header className="topbar"><strong>ONE Classics Nexus</strong><div><span>Intake Staff</span><FaChevronDown/><i/><FaCircleQuestion/><span>Help</span><i/><span>—</span><span>□</span><span>×</span></div></header></>;
}

function Sidebar({ onToast }) {
  return <aside className="sidebar">{navItems.map(([Icon,label]) => <button key={label} className={label === "Appraisal Requests" ? "active" : ""} onClick={()=>label !== "Appraisal Requests" && onToast(`${label} is outside this prototype.`)}><Icon/><span>{label}</span></button>)}</aside>;
}

function Field({ label, required, children }) {
  return <label className="field"><span>{label}{required && <em>*</em>}</span>{children}</label>;
}

function QueueDrawer({ open, onClose, onSelect }) {
  if (!open) return null;
  return <div className="drawer-backdrop" onMouseDown={e=>e.target===e.currentTarget && onClose()}><aside className="queue-drawer"><header><div><h2>Request Queue</h2><p>12 active requests</p></div><button onClick={onClose} aria-label="Close request queue"><FaXmark/></button></header><div className="queue-search"><FaMagnifyingGlass/><input placeholder="Search requests"/></div><div className="queue-list">{requests.map(item=><button key={item.number} onClick={()=>onSelect(item)}><div><b>{item.number}</b><span>{item.client}</span><small>{item.vehicle}</small></div><span className="queue-status">{item.status}</span><FaChevronRight/></button>)}</div></aside></div>;
}

function UserDialog({ user, onClose, onSave }) {
  const [draft,setDraft] = useState(user || {type:"Individual",name:"",relationship:"",isClient:false});
  const update=(key,value)=>setDraft({...draft,[key]:value});
  return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget && onClose()}><div className="modal" role="dialog" aria-modal="true"><header><h2>{user?"Edit":"Add"} Intended User</h2><button aria-label="Close" onClick={onClose}><FaXmark/></button></header><Field label="Type" required><select value={draft.type} onChange={e=>update("type",e.target.value)}><option>Individual</option><option>Organization</option></select></Field><Field label="Name" required><input autoFocus value={draft.name} onChange={e=>update("name",e.target.value)}/></Field><Field label="Relationship" required><input value={draft.relationship} onChange={e=>update("relationship",e.target.value)}/></Field><label className="check"><input type="checkbox" checked={draft.isClient} onChange={e=>update("isClient",e.target.checked)}/><span>This intended user is the client</span></label><footer><Button onClick={onClose}>Cancel</Button><Button icon={FaCircleCheck} tone="primary" disabled={!draft.name.trim()||!draft.relationship.trim()} onClick={()=>onSave(draft)}>Save User</Button></footer></div></div>;
}

function VehicleCard({ vehicleId, setVehicleId, setDirty }) {
  const vehicle=vehicles.find(v=>v.id===vehicleId);
  return <section className="card vehicle-card"><header><div className="card-icon"><FaCarSide/></div><div><span className="eyebrow">1 · SUBJECT</span><h2>Vehicle</h2></div><span className={vehicle?"complete":"incomplete"}>{vehicle?<><FaCircleCheck/> Ready</>:<><FaCircleExclamation/> Required</>}</span></header><Field label="Vehicle" required><div className="select-search"><select value={vehicleId} onChange={e=>{setVehicleId(e.target.value);setDirty(true)}}><option value="">Select vehicle…</option>{vehicles.map(v=><option key={v.id} value={v.id}>{v.name}</option>)}</select><button aria-label="Search vehicles"><FaMagnifyingGlass/></button></div></Field>{vehicle && <div className="compact-summary"><FaCarSide/><div><b>{vehicle.name}</b><span>VIN {vehicle.vin}</span></div><button><FaPen/> Edit vehicle</button></div>}</section>;
}

function ClientCard({ clientId,setClientId,contactId,setContactId,setDirty }) {
  const client=clients[clientId], contact=client?.contacts.find(c=>c.id===contactId);
  return <section className="card client-card"><header><div className="card-icon"><FaBuilding/></div><div><span className="eyebrow">2 · REQUESTOR</span><h2>Client and Contact</h2></div><span className={client?"complete":"incomplete"}>{client?<><FaCircleCheck/> Ready</>:<><FaCircleExclamation/> Required</>}</span></header><div className="two-fields"><Field label="Client" required><select value={clientId} onChange={e=>{const id=e.target.value;setClientId(id);setContactId(clients[id]?.contacts[0]?.id||"");setDirty(true)}}><option value="">Select client…</option><option value="smith">Smith Automotive Collection</option><option value="hartwell">Hartwell Collection</option></select></Field><Field label="Primary Contact"><select disabled={!client} value={contactId} onChange={e=>{setContactId(e.target.value);setDirty(true)}}><option value="">No contact selected</option>{client?.contacts.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></Field></div>{contact && <div className="contact-strip"><span><FaUser/>{contact.name}</span><span><FaEnvelope/>{contact.email}</span><span><FaPhone/>{contact.phone}</span></div>}</section>;
}

function IntendedUsersCard({ users,setUsers,selected,setSelected,setDialog,setDirty }) {
  const active=users;
  return <section className="card users-card"><header><div className="card-icon"><FaUser/></div><div><span className="eyebrow">3 · USE OF REPORT</span><h2>Intended Users</h2></div><span className={active.length?"complete":"incomplete"}>{active.length?<><FaCircleCheck/> {active.length} added</>:<><FaCircleExclamation/> Required</>}</span></header><div className="user-actions"><Button icon={FaPlus} tone="primary" onClick={()=>{setSelected(null);setDialog(true)}}>Add User</Button><Button icon={FaPen} disabled={!selected} onClick={()=>setDialog(true)}>Edit</Button><Button icon={FaTrashCan} disabled={!selected} onClick={()=>{setUsers(users.filter(u=>u.id!==selected));setSelected(null);setDirty(true)}}>Remove</Button></div><div className="user-list">{active.map(user=><button key={user.id} className={selected===user.id?"selected":""} onClick={()=>setSelected(user.id)}><span className="avatar">{user.type==="Organization"?<FaBuilding/>:<FaUser/>}</span><span><b>{user.name}</b><small>{user.relationship}</small></span>{user.isClient&&<em>Client</em>}</button>)}{!active.length&&<div className="empty"><FaUser/><b>No intended users yet</b><span>Add the people or organizations permitted to rely on the appraisal.</span></div>}</div></section>;
}

export function App() {
  const [request,setRequest]=useState(requests[0]),[status,setStatus]=useState("Draft"),[queueOpen,setQueueOpen]=useState(false),[vehicleId,setVehicleId]=useState("mustang"),[clientId,setClientId]=useState("smith"),[contactId,setContactId]=useState("john"),[users,setUsers]=useState(initialUsers),[selected,setSelected]=useState(1),[dialog,setDialog]=useState(false),[dirty,setDirty]=useState(false),[toast,setToast]=useState("");
  const selectedUser=users.find(u=>u.id===selected), checks=useMemo(()=>[{label:"Vehicle",ok:!!vehicleId},{label:"Client",ok:!!clientId},{label:"Contact",ok:true,optional:true},{label:"Intended user",ok:users.length>0}],[vehicleId,clientId,users]), ready=checks.filter(c=>!c.optional).every(c=>c.ok);
  const notify=text=>{setToast(text);window.setTimeout(()=>setToast(""),2400)};
  const save=()=>{setDirty(false);notify("Draft saved.")}, submit=()=>{if(!ready){notify("Complete the required information first.");return}setStatus("Submitted");setDirty(false);notify("Appraisal Request submitted.")};
  return <div className="app-shell"><ShellHeader/><Sidebar onToast={notify}/><main className="workspace"><div className="page-head"><div><Button icon={FaBars} onClick={()=>setQueueOpen(true)} className="queue-button">Request Queue <span className="count">12</span></Button><h1>Appraisal Request Intake</h1><p>Capture only the people and vehicle needed to start the appraisal.</p></div><div className="request-id"><span>Request</span><b>{request.number}</b><em>{status}</em></div></div><div className="layout"><div className="form-column"><VehicleCard vehicleId={vehicleId} setVehicleId={setVehicleId} setDirty={setDirty}/><ClientCard clientId={clientId} setClientId={setClientId} contactId={contactId} setContactId={setContactId} setDirty={setDirty}/><IntendedUsersCard users={users} setUsers={setUsers} selected={selected} setSelected={setSelected} setDialog={setDialog} setDirty={setDirty}/><section className="readiness"><div><span className="eyebrow">READINESS</span><h2>{ready?"Ready to submit":"A little more information is needed"}</h2></div><div>{checks.map(c=><span key={c.label} className={c.ok?"ok":"missing"}>{c.ok?<FaCircleCheck/>:<FaCircleExclamation/>}{c.label}{c.optional&&<small> optional</small>}</span>)}</div></section></div><aside className="command-rail"><h2>Actions</h2><Button icon={FaFloppyDisk} tone="primary" onClick={save}>{dirty?"Save Draft*":"Save Draft"}</Button><Button icon={FaCircleCheck} onClick={()=>notify(ready?"Request is ready to submit.":"Required information is missing.")}>Check Ready</Button><Button icon={FaPaperPlane} tone="dark" disabled={status!=="Draft"} onClick={submit}>Submit Request</Button><hr/><p><b>Minimal intake</b><br/>Detailed scope, value definition, dates, attachments, and assignment controls are completed after intake.</p><Button icon={FaXmark} disabled={status!=="Draft"} onClick={()=>{setStatus("Cancelled");notify("Request cancelled.")}}>Cancel Request</Button></aside></div></main><QueueDrawer open={queueOpen} onClose={()=>setQueueOpen(false)} onSelect={item=>{setRequest(item);setStatus(item.status);setQueueOpen(false);notify(`${item.number} opened.`)}}/>{dialog&&<UserDialog user={selectedUser} onClose={()=>setDialog(false)} onSave={draft=>{setUsers(selectedUser?users.map(u=>u.id===selectedUser.id?{...u,...draft}:u):[...users,{...draft,id:Date.now()}]);setDialog(false);setDirty(true)}}/>}{toast&&<div className="toast"><FaCircleCheck/>{toast}</div>}</div>;
}
