# Option 3 Minimal Appraisal Request — Design QA

## Comparison Target

- Source design language: `/workspace/scratch/7adbddf7fc8b/upload/01-file_000000009e5481fda640987977678021.png` (`1536 × 961`).
- Intentional redesign requirement: retain the ONE Classics Nexus shell and option 3 Guided Request Workspace pattern while reducing primary intake to Vehicle, Client, Contact, and Intended Users.
- Browser-rendered implementation: Cloud Browser capture of `http://terminal.local:4173/`; the browser surface does not expose a durable local screenshot path.
- Verified viewport: desktop Work Mode browser, device density `1×`.
- State: `AR-2026-00418`, Draft, all three minimal information cards complete, readiness visible.

## Findings

No actionable P0, P1, or P2 findings remain.

- Fonts and typography: Segoe UI hierarchy matches the source shell, with a larger intake title and compact card headings suited to the simplified flow.
- Spacing and layout rhythm: the locked left navigation and top bar remain consistent with Nexus. The former five-step editor is intentionally replaced by three vertically ordered cards and a persistent action rail.
- Colors and visual tokens: Nexus navy `#0E2841`, active blue, pale blue summaries, green readiness states, neutral borders, and white card surfaces remain consistent with the source.
- Image and icon fidelity: the source contains no photography or custom illustration. Font Awesome supplies consistent navigation and command icons; no placeholder imagery is used.
- Copy and content: the screen is limited to Vehicle, Client, Primary Contact, and Intended Users. Detailed scope, value definition, dates, attachments, audit history, row version, and assignment controls are explicitly deferred after intake.
- Accessibility and behavior: all primary inputs and actions are native controls. The request queue, Intended User dialog, disabled lifecycle actions, and readiness states are exposed through the accessibility tree.

## Comparison History

### Initial review

- P2: the heading “New Appraisal Request” became inaccurate when the request queue opened an existing record.
  - Fix: changed the heading to “Appraisal Request Intake.”
- P2: the simplified design still needed a clear boundary for removed information.
  - Fix: added a concise “Minimal intake” note in the persistent action rail explaining that detailed assignment information is completed after intake.

### Final browser evidence

- Full view visually checked against the source shell for navigation width, top-bar height, typography, color, borders, and command styling.
- Focused review completed for Vehicle, Client/Contact, Intended Users, readiness, and the action rail.
- Primary interactions tested:
  - Open request queue.
  - Select an existing Under Review request and verify lifecycle actions lock.
  - Open Add Intended User.
  - Enter and save a new Intended User.
  - Submit a ready Draft and verify status changes to Submitted.
- Runtime diagnostics after reload: `0 errors`.
- Production build and four Sites-worker tests passed.

## Follow-up Polish

- P3: production integration should replace in-memory records with `IAppraisalRequestApiClient` calls.
- P3: the Vehicle and Client search buttons are visual integration points for the existing Nexus selector dialogs.

**final result: passed**
