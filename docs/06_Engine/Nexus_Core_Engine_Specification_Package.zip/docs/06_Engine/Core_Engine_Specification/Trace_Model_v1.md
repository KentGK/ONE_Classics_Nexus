# Trace Model v1.0

## Purpose
Defines valuation explainability and traceability.

## Trace Types
- INPUT
- CALCULATION
- COMPARABLE
- CONDITION
- CONFIDENCE
- FINAL_VALUE

## Database Mapping
valuation_trace_lines
