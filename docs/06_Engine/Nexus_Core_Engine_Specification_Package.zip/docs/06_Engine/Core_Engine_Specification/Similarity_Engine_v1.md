# Similarity Engine v1.0

## Purpose
Defines comparable scoring logic.

## Formula
similarity_score = Σ(weight × factor_score)

## Factors
- Year
- Make
- Model
- Mileage
- Condition
- Originality
