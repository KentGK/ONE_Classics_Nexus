# AVM Math Specification v1.0

## 1. Purpose
Defines deterministic valuation mathematics aligned to locked AVM v3.0 assumptions.

## 2. Core Equation
FinalValue = Median(AdjustedComparables) × ConditionIndex × MarketFactor × RedFlagFactor

## 3. Constraints
- Deterministic execution only
- Immutable valuation runs
- 0–5 scoring normalized to 0–100
