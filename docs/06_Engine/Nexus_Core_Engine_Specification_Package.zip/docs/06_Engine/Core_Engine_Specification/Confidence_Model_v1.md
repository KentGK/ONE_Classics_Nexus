# Confidence Model v1.0

## Formula
Confidence = CompDensity × SimilarityStrength × InspectionCompleteness × DataQuality

## Bands
- High ≥ 0.80
- Medium 0.50–0.79
- Low < 0.50
