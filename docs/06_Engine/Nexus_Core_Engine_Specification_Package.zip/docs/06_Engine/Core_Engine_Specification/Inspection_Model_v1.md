# Inspection Model v1.0

## 1. Purpose
Defines the canonical Nexus 12-system inspection contract.

## 2. Locked Canonical Mapping
1. Body & Exterior
2. Frame & Structure
3. Engine / Powertrain
...
12. Road Test & Functional

## 3. Schema Alignment
condition_scores:
- system_number
- system_key
- score_0_to_5
- weight
- is_red_flag
- notes
