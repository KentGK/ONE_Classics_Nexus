namespace ONE_Classics_Nexus.API.Contracts.Inspections;

public sealed record CreateInspectionRequest(
    Guid AppraisalId,
    string InspectionType,
    string? InspectorName,
    DateTime? InspectionDateUtc,
    string? Notes);

public sealed record InspectionResponse(
    Guid InspectionId,
    Guid AppraisalId,
    string InspectionType,
    string? InspectorName,
    DateTime? InspectionDateUtc,
    IReadOnlyList<InspectionScoreDto> Scores,
    DateTime CreatedAtUtc,
    DateTime? UpdatedAtUtc);

public sealed record SaveInspectionScoresRequest(
    IReadOnlyList<InspectionScoreDto> Scores);

public sealed record InspectionScoreDto(
    int SystemNumber,
    string SystemKey,
    decimal Score0To5,
    bool IsRedFlag,
    string? Notes);
