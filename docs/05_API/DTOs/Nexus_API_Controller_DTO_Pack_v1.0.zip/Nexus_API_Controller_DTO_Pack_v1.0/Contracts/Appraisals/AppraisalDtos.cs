namespace ONE_Classics_Nexus.API.Contracts.Appraisals;

public sealed record CreateAppraisalRequest(
    Guid VehicleId,
    string? AppraisalType,
    string? Status,
    string? Notes);

public sealed record UpdateAppraisalRequest(
    string Status,
    string? Notes,
    int? RowVersion);

public sealed record AppraisalResponse(
    Guid AppraisalId,
    Guid VehicleId,
    string Status,
    string? AppraisalType,
    string? Notes,
    DateTime CreatedAtUtc,
    DateTime? UpdatedAtUtc,
    int? RowVersion);
