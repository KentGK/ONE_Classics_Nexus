namespace ONE_Classics_Nexus.API.Contracts.Vehicles;

public sealed record CreateVehicleRequest(
    string Vin,
    int Year,
    string Make,
    string Model,
    string? Trim,
    string? BodyStyle,
    string? Engine,
    string? Transmission,
    string? Drivetrain,
    int? Mileage);

public sealed record UpdateVehicleRequest(
    string Vin,
    int Year,
    string Make,
    string Model,
    string? Trim,
    string? BodyStyle,
    string? Engine,
    string? Transmission,
    string? Drivetrain,
    int? Mileage);

public sealed record VehicleResponse(
    Guid VehicleId,
    string Vin,
    int Year,
    string Make,
    string Model,
    string? Trim,
    string? BodyStyle,
    string? Engine,
    string? Transmission,
    string? Drivetrain,
    int? Mileage,
    DateTime CreatedAtUtc,
    DateTime? UpdatedAtUtc);
