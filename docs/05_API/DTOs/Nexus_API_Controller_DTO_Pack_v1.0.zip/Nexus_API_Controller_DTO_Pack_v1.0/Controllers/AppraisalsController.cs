using Microsoft.AspNetCore.Mvc;
using ONE_Classics_Nexus.API.ApplicationPorts;
using ONE_Classics_Nexus.API.Contracts.Appraisals;

namespace ONE_Classics_Nexus.API.Controllers;

[ApiController]
[Route("api/appraisals")]
public sealed class AppraisalsController : ControllerBase
{
    private readonly IAppraisalApiService _service;

    public AppraisalsController(IAppraisalApiService service) => _service = service;

    [HttpPost]
    [ProducesResponseType(typeof(AppraisalResponse), StatusCodes.Status201Created)]
    public async Task<ActionResult<AppraisalResponse>> Create([FromBody] CreateAppraisalRequest request, CancellationToken cancellationToken)
    {
        if (request.VehicleId == Guid.Empty) return ValidationProblem("VehicleId is required.");
        var created = await _service.CreateAsync(request, cancellationToken);
        return CreatedAtAction(nameof(GetById), new { appraisalId = created.AppraisalId }, created);
    }

    [HttpGet("{appraisalId:guid}")]
    [ProducesResponseType(typeof(AppraisalResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<AppraisalResponse>> GetById(Guid appraisalId, CancellationToken cancellationToken)
    {
        var appraisal = await _service.GetByIdAsync(appraisalId, cancellationToken);
        return appraisal is null ? NotFound() : Ok(appraisal);
    }

    [HttpPut("{appraisalId:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Update(Guid appraisalId, [FromBody] UpdateAppraisalRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Status)) return ValidationProblem("Status is required.");
        var updated = await _service.UpdateAsync(appraisalId, request, cancellationToken);
        return updated ? NoContent() : NotFound();
    }
}
