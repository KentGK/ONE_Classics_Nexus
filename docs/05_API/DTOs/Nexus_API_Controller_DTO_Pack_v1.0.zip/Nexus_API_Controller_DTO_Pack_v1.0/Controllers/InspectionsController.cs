using Microsoft.AspNetCore.Mvc;
using ONE_Classics_Nexus.API.ApplicationPorts;
using ONE_Classics_Nexus.API.Contracts.Inspections;

namespace ONE_Classics_Nexus.API.Controllers;

[ApiController]
[Route("api/inspections")]
public sealed class InspectionsController : ControllerBase
{
    private readonly IInspectionApiService _service;
    private static readonly HashSet<string> ValidSystemKeys = new(StringComparer.OrdinalIgnoreCase)
    {
        "body_exterior", "frame_structure", "powertrain", "transmission_driveline",
        "suspension_steering", "braking_system", "electrical_system", "interior",
        "wheels_tires", "trim_glass_details", "documentation_provenance", "road_test_functional"
    };

    public InspectionsController(IInspectionApiService service) => _service = service;

    [HttpPost]
    [ProducesResponseType(typeof(InspectionResponse), StatusCodes.Status201Created)]
    public async Task<ActionResult<InspectionResponse>> Create([FromBody] CreateInspectionRequest request, CancellationToken cancellationToken)
    {
        if (request.AppraisalId == Guid.Empty) return ValidationProblem("AppraisalId is required.");
        if (string.IsNullOrWhiteSpace(request.InspectionType)) return ValidationProblem("InspectionType is required.");
        var created = await _service.CreateAsync(request, cancellationToken);
        return CreatedAtAction(nameof(GetById), new { inspectionId = created.InspectionId }, created);
    }

    [HttpGet("{inspectionId:guid}")]
    [ProducesResponseType(typeof(InspectionResponse), StatusCodes.Status200OK)]
    public async Task<ActionResult<InspectionResponse>> GetById(Guid inspectionId, CancellationToken cancellationToken)
    {
        var inspection = await _service.GetByIdAsync(inspectionId, cancellationToken);
        return inspection is null ? NotFound() : Ok(inspection);
    }

    [HttpPut("{inspectionId:guid}/scores")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> SaveScores(Guid inspectionId, [FromBody] SaveInspectionScoresRequest request, CancellationToken cancellationToken)
    {
        var validationError = ValidateScores(request);
        if (validationError is not null) return ValidationProblem(validationError);

        var saved = await _service.SaveScoresAsync(inspectionId, request, cancellationToken);
        return saved ? NoContent() : NotFound();
    }

    private static string? ValidateScores(SaveInspectionScoresRequest request)
    {
        if (request.Scores.Count != 12) return "Exactly 12 inspection scores are required.";
        if (request.Scores.Select(s => s.SystemNumber).Distinct().Count() != 12) return "SystemNumber values must be unique.";

        foreach (var score in request.Scores)
        {
            if (score.SystemNumber is < 1 or > 12) return "SystemNumber must be between 1 and 12.";
            if (!ValidSystemKeys.Contains(score.SystemKey)) return $"Invalid system_key: {score.SystemKey}.";
            if (score.Score0To5 < 0m || score.Score0To5 > 5m) return "Score0To5 must be between 0 and 5.";
        }

        return null;
    }
}
