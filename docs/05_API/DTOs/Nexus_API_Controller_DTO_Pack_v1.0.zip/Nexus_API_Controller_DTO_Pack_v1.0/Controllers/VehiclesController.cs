using Microsoft.AspNetCore.Mvc;
using ONE_Classics_Nexus.API.ApplicationPorts;
using ONE_Classics_Nexus.API.Contracts.Vehicles;

namespace ONE_Classics_Nexus.API.Controllers;

[ApiController]
[Route("api/vehicles")]
public sealed class VehiclesController : ControllerBase
{
    private readonly IVehicleApiService _service;

    public VehiclesController(IVehicleApiService service) => _service = service;

    [HttpPost]
    [ProducesResponseType(typeof(VehicleResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<VehicleResponse>> Create([FromBody] CreateVehicleRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Vin)) return ValidationProblem("VIN is required.");
        if (request.Year < 1886 || request.Year > DateTime.UtcNow.Year + 1) return ValidationProblem("Year is outside the supported range.");
        if (string.IsNullOrWhiteSpace(request.Make)) return ValidationProblem("Make is required.");
        if (string.IsNullOrWhiteSpace(request.Model)) return ValidationProblem("Model is required.");

        var created = await _service.CreateAsync(request, cancellationToken);
        return CreatedAtAction(nameof(GetById), new { vehicleId = created.VehicleId }, created);
    }

    [HttpGet("{vehicleId:guid}")]
    [ProducesResponseType(typeof(VehicleResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<VehicleResponse>> GetById(Guid vehicleId, CancellationToken cancellationToken)
    {
        var vehicle = await _service.GetByIdAsync(vehicleId, cancellationToken);
        return vehicle is null ? NotFound() : Ok(vehicle);
    }

    [HttpPut("{vehicleId:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid vehicleId, [FromBody] UpdateVehicleRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Vin)) return ValidationProblem("VIN is required.");
        var updated = await _service.UpdateAsync(vehicleId, request, cancellationToken);
        return updated ? NoContent() : NotFound();
    }
}
