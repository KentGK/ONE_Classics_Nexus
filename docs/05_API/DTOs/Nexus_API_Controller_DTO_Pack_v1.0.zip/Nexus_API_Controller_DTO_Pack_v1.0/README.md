# Nexus API Controller + DTO Pack v1.0

## Purpose
Drop these files into `ONE_Classics_Nexus.API` to establish the API contract layer for:

- Vehicles
- Appraisals
- Inspections
- Comparables
- Valuation
- Reports

## Folder Placement

```text
ONE_Classics_Nexus.API/
├── Controllers/
├── Contracts/
│   ├── Vehicles/
│   ├── Appraisals/
│   ├── Inspections/
│   ├── Comparables/
│   ├── Valuation/
│   └── Reports/
└── ApplicationPorts/
```

## Important Integration Note

The included `ApplicationPorts/INexusApiServices.cs` defines thin API-facing service interfaces. Implement these in the Application layer or create adapter classes over existing handlers/repositories.

This avoids domain leakage and keeps controllers stable while the underlying handlers evolve.

## Required DI Registrations

Register implementations for:

```csharp
builder.Services.AddScoped<IVehicleApiService, VehicleApiService>();
builder.Services.AddScoped<IAppraisalApiService, AppraisalApiService>();
builder.Services.AddScoped<IInspectionApiService, InspectionApiService>();
builder.Services.AddScoped<IComparableApiService, ComparableApiService>();
builder.Services.AddScoped<IValuationApiService, ValuationApiService>();
builder.Services.AddScoped<IReportApiService, ReportApiService>();
```

## Locked Nexus Rules Enforced

- GUID route constraints avoid invalid-ID 404/Swagger ambiguity where applicable.
- Inspection scores require exactly 12 systems.
- `score_0_to_5` range is enforced as 0–5.
- Canonical 12 `system_key` values are validated.
- Valuation routes are consolidated in one controller to avoid Swagger conflicts.
