using ONE_Classics_Nexus.API.Contracts.Appraisals;
using ONE_Classics_Nexus.API.Contracts.Comparables;
using ONE_Classics_Nexus.API.Contracts.Inspections;
using ONE_Classics_Nexus.API.Contracts.Reports;
using ONE_Classics_Nexus.API.Contracts.Valuation;
using ONE_Classics_Nexus.API.Contracts.Vehicles;

namespace ONE_Classics_Nexus.API.ApplicationPorts;

// Adapter ports used by the API controllers. Implement these in the Application layer,
// or create thin adapters over existing handlers/repositories.
public interface IVehicleApiService
{
    Task<VehicleResponse> CreateAsync(CreateVehicleRequest request, CancellationToken cancellationToken);
    Task<VehicleResponse?> GetByIdAsync(Guid vehicleId, CancellationToken cancellationToken);
    Task<bool> UpdateAsync(Guid vehicleId, UpdateVehicleRequest request, CancellationToken cancellationToken);
}

public interface IAppraisalApiService
{
    Task<AppraisalResponse> CreateAsync(CreateAppraisalRequest request, CancellationToken cancellationToken);
    Task<AppraisalResponse?> GetByIdAsync(Guid appraisalId, CancellationToken cancellationToken);
    Task<bool> UpdateAsync(Guid appraisalId, UpdateAppraisalRequest request, CancellationToken cancellationToken);
}

public interface IInspectionApiService
{
    Task<InspectionResponse> CreateAsync(CreateInspectionRequest request, CancellationToken cancellationToken);
    Task<InspectionResponse?> GetByIdAsync(Guid inspectionId, CancellationToken cancellationToken);
    Task<bool> SaveScoresAsync(Guid inspectionId, SaveInspectionScoresRequest request, CancellationToken cancellationToken);
}

public interface IComparableApiService
{
    Task<ComparableResponse> CreateAsync(Guid appraisalId, CreateComparableRequest request, CancellationToken cancellationToken);
    Task<ComparableListResponse> GetByAppraisalIdAsync(Guid appraisalId, CancellationToken cancellationToken);
    Task<bool> UpdateAsync(Guid comparableId, UpdateComparableRequest request, CancellationToken cancellationToken);
}

public interface IValuationApiService
{
    Task<ValuationRunResponse> RunAsync(Guid appraisalId, RunValuationRequest request, CancellationToken cancellationToken);
    Task<ValuationRunListResponse> GetRunsByAppraisalIdAsync(Guid appraisalId, CancellationToken cancellationToken);
    Task<ValuationRunDetailResponse?> GetRunDetailAsync(Guid valuationRunId, CancellationToken cancellationToken);
}

public interface IReportApiService
{
    Task<ReportResponse> CreateAsync(Guid appraisalId, CreateReportRequest request, CancellationToken cancellationToken);
    Task<ReportResponse?> GetLatestByAppraisalIdAsync(Guid appraisalId, CancellationToken cancellationToken);
}
